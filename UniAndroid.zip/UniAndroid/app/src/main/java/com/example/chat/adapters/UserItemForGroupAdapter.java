package com.example.chat.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.AddUserToGroup;
import com.example.chat.OpenedChat;
import com.example.chat.R;
import com.example.chat.SearchUsers;
import com.example.chat.SocketHelper;
import com.example.chat.models.User;
import com.example.chat.storage.MainFilesHelper;

import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class UserItemForGroupAdapter extends RecyclerView.Adapter<UserItemForGroupAdapter.ViewHolder> {

    public ArrayList<User> users;
    public static int receiverId;
    private Context context;


    public UserItemForGroupAdapter(ArrayList<User> users, Context context) {
        this.users = users;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_search_user_for_group, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User user = users.get(position);
        holder.username.setText(user.getUsername());

        holder.buttonSendFriendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserItemForGroupAdapter.receiverId = user.getId();

                AddToGroup commThread = new AddToGroup();
                new Thread(commThread).start();

                holder.buttonSendFriendRequest.setVisibility(View.INVISIBLE);
            }
        });
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView username;
        public Button buttonSendFriendRequest;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            username = (TextView) itemView.findViewById(R.id.username);
            buttonSendFriendRequest = (Button) itemView.findViewById(R.id.button_send_friend_request);
        }
    }

    class AddToGroup implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject frData = new JSONObject();
                frData.put("requestType", SocketHelper.ADD_USER_TO_GROUP);
                frData.put("userID", UserItemForGroupAdapter.receiverId);
                frData.put("chatID", OpenedChat.openedChatID);

                String data = frData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
