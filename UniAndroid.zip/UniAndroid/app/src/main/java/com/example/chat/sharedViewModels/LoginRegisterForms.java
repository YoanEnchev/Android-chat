package com.example.chat.sharedViewModels;

import android.util.Log;
import android.util.Patterns;

public class LoginRegisterForms {

    public static String isUsernameValid(String username) {

        return ""; // Username is correct.
    }

    public static String isPasswordValid(String password) {

        if(password == null || password.trim().length() == 0) {
            return "Password needs to be filled.";
        }

        if(password.trim().length() < 5) {
            return "Password needs to be at least 5 symbols.";
        }

        return ""; // Valid password.
    }

}
