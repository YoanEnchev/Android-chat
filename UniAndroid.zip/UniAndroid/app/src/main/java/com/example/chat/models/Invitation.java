package com.example.chat.models;

public class Invitation {
    private String username;
    private String status;

    public static final int STATUS_PENDING = 0;
    public static final int STATUS_ACCEPTED = 1;
    public static final int STATUS_DENIED = 2;

    public Invitation(String username, String status) {
        this.setUsername(username);
        this.setStatus(status);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId() {
        return 1;
    }
}
