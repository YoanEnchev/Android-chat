package com.example.chat.models;

import com.example.chat.ChatsListing;
import com.example.chat.storage.MainFilesHelper;

import java.util.ArrayList;

public class Chat {

    private int id;
    private String name;

    public Chat(int id, String nameVal) {
        this.setId(id);
        this.setName(nameVal);
    }

    public String getName() {
        if(name.length() == 0) {
            return "New Group";
        }

        return name;
    }

    public void setName(String nameVal) {
        this.name = nameVal;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
