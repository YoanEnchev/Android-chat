package com.example.chat.models;

import java.util.ArrayList;

public class Chat {

    private int id;
    private String name;

    public Chat(int id, String nameVal) {
        this.setId(id);
        this.setName(nameVal);
    }

    public String getName() {
        return name;
    }

    public void setName(String nameVal) {
        this.name = nameVal;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
