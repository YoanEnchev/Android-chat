package com.example.chat;

import android.os.Bundle;

import com.example.chat.adapters.UserItemAdapter;
import com.example.chat.adapters.UserItemForGroupAdapter;
import com.example.chat.models.User;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class AddUserToGroup extends AppCompatActivity {

    public static UserItemForGroupAdapter adapter;
    public static AddUserToGroup context;
    public static String searchPhrase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user_to_group);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView usersList = (RecyclerView) findViewById(R.id.usersList);
        usersList.setLayoutManager(new LinearLayoutManager(this));

        // Initially no users are shown.
        ArrayList<User> users = new ArrayList<>();
        UserItemForGroupAdapter adapter = new UserItemForGroupAdapter(users, this);
        usersList.setAdapter(adapter);

        AddUserToGroup.adapter = adapter;

        Button searchBtn = findViewById(R.id.button_search_users);
        EditText editTextPhrase = findViewById(R.id.search_username);


        context = this;

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                AddUserToGroup.searchPhrase = editTextPhrase.getText().toString();

                //SearchUsersForGroup commThread = new SearchUsersForGroup();
                //new Thread(commThread).start();

                runOnUiThread(() -> {
                    String usersResponseForGroups = "[{\"name\":\"Al\", \"id\": 2}, {\"name\":\"Xsdf\", \"id\": 3}, {\"name\":\"Sop\", \"id\": 4}]";
                    JSONArray usersResponseForGroupsArr = null;
                    try {
                        usersResponseForGroupsArr = new JSONArray(usersResponseForGroups);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    AddUserToGroup.context.updateUsersList(usersResponseForGroupsArr);
                });
            }
        });
    }

    public void updateUsersList(JSONArray usersArr) {

        ArrayList<User> users = new ArrayList<>();

        try {
            for (int i = 0; i < usersArr.length(); i++) {
                JSONObject obj = (JSONObject) usersArr.get(i);
                User user = new User(obj.getString("name") ,obj.getInt("id"));

                users.add(user);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        AddUserToGroup.adapter.users = users;
        AddUserToGroup.adapter.notifyDataSetChanged();
    }

    class SearchUsersForGroup implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.SEARCH_USERS_FOR_INVITATION);
                regData.put("phrase", AddUserToGroup.searchPhrase);

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}