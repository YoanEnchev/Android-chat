package com.example.chat.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.R;
import com.example.chat.models.Invitation;

import java.util.ArrayList;

public class InvitationAdapter extends RecyclerView.Adapter<InvitationAdapter.ViewHolder> {

    public ArrayList<Invitation> invitations;
    private Context context;

    public static InvitationAdapter adapterContext;

    public InvitationAdapter(ArrayList<Invitation> invitations, Context context) {
        this.invitations = invitations;
        this.context = context;

        InvitationAdapter.adapterContext = this;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sent_invitation, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Invitation inv = invitations.get(position);
        holder.invitationUsername.setText(inv.getUsername());
        holder.invitationStatus.setText(inv.getStatus());
    }

    @Override
    public int getItemCount() {
        return invitations.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView invitationUsername;
        public TextView invitationStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            invitationUsername = (TextView) itemView.findViewById(R.id.invitationUsername);
            invitationStatus = (TextView) itemView.findViewById(R.id.invitationStatus);
        }
    }
}
