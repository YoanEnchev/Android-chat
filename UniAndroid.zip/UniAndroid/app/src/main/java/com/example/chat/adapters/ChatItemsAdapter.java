package com.example.chat.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.OpenedChat;
import com.example.chat.R;
import com.example.chat.models.Chat;

import java.util.ArrayList;

public class ChatItemsAdapter extends RecyclerView.Adapter<ChatItemsAdapter.ViewHolder> {

    ArrayList<Chat> chats;
    private Context context;

    public ChatItemsAdapter(ArrayList<Chat> chats, Context context) {
        this.chats = chats;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Chat chat = chats.get(position);

        holder.usernameTextView.setText(chat.getName());
        // holder.usernameTextView

        holder.usernameTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                OpenedChat.openedChatID = chat.getId();
                Intent intent = new Intent("android.intent.action.OpenedChat");
                context.startActivity(intent);

                Log.d("xyz", "onCLick");
            }
        });
    }

    @Override
    public int getItemCount() {
        return chats.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView usernameTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            usernameTextView = (TextView) itemView.findViewById(R.id.username);
        }
    }
}
