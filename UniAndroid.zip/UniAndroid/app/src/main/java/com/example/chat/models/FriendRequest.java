package com.example.chat.models;

public class FriendRequest {
    private int id;
    private String senderName;
    private int senderId;

    public FriendRequest(int id, String senderName, int senderId) {
        this.setId(id);
        this.setSenderName(senderName);
        this.setSenderId(senderId);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }
}
