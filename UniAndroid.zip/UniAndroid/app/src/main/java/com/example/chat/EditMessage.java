package com.example.chat;

import android.content.Intent;
import android.os.Bundle;

import com.example.chat.adapters.MessageItemsAdapter;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class EditMessage extends AppCompatActivity {

    private EditText textboxMessage;
    private Button editButton;
    private static String messageToEdit;
    private static EditMessage context;

    public static int chatID = 0;
    public static int messageID = 0;
    public static String messageText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_message);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textboxMessage = (EditText) findViewById(R.id.textboxMessage);
        editButton = (Button) findViewById(R.id.button_edit_message);

        textboxMessage.setText(messageText);

        EditMessage that = this;
        EditMessage.context = this;

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String messageText = textboxMessage.getText().toString();

                if(messageText.length() > 0) {

                    EditMessage.messageToEdit = messageText;

                    that.onBackPressed();

                    Toast.makeText(that, "Message has been edited.", Toast.LENGTH_LONG).show();

                    EditMessageTrait commThread = new EditMessageTrait();
                    new Thread(commThread).start();
                }
                else {
                    Toast.makeText(that, "Message cannot be empty.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    class EditMessageTrait implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.EDIT_MESSAGE);
                regData.put("text", EditMessage.messageToEdit);
                regData.put("user", MainFilesHelper.getUserID(context));
                regData.put("chatID", OpenedChat.openedChatID);

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}