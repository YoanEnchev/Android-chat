package com.example.chat;

import android.content.Intent;
import android.os.Bundle;

import com.example.chat.adapters.MessageItemsAdapter;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class EditMessage extends AppCompatActivity {

    private EditText textboxMessage;
    private Button editButton;

    public static int chatID = 0;
    public static int messageID = 0;
    public static String messageText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_message);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textboxMessage = (EditText) findViewById(R.id.textboxMessage);
        editButton = (Button) findViewById(R.id.button_edit_message);

        textboxMessage.setText(messageText);

        EditMessage that = this;

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String messageText = textboxMessage.getText().toString();

                if(messageText.length() > 0) {
                    editMessageAndUpdateLocalFiles(chatID, messageID, messageText);
                    that.onBackPressed();

                    Toast.makeText(that, "Message has been edited.", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(that, "Message cannot be empty.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void editMessageAndUpdateLocalFiles(int chatID, int messageID, String newText) {
        // update local file:
        String messageStr = MainFilesHelper.readFile("messages_" + chatID + ".json", this);

        try {
            JSONArray messagesArrOld = new JSONArray(messageStr);
            JSONArray messagesArrNew = new JSONArray();

            for(int i = 0; i < messagesArrOld.length(); i++) {
                JSONObject jsonObj = (JSONObject) messagesArrOld.get(i);

                if(jsonObj.getInt("id") == messageID) {
                    jsonObj.put("message", newText);
                }

                messagesArrNew.put(jsonObj);
            }

            MainFilesHelper.writeToFile("messages_" + chatID + ".json", messagesArrNew.toString(), this);

            Intent intent = new Intent("android.intent.action.OpenedChat");
            startActivity(intent);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}