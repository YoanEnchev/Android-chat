package com.example.chat;

import android.os.Bundle;

import com.example.chat.adapters.FriendRequestAdapter;
import com.example.chat.adapters.InvitationAdapter;
import com.example.chat.models.FriendRequest;
import com.example.chat.models.Invitation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class InvitationsListing extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitations_listing);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView receivedFriendRequestsList = (RecyclerView) findViewById(R.id.friendsRequestList);
        receivedFriendRequestsList.setLayoutManager(new LinearLayoutManager(this));

        // TODO: send server request:
        FriendRequest fr1 = new FriendRequest(1, "Alice", 1);
        FriendRequest fr2 = new FriendRequest(2, "Smith", 2);
        FriendRequest fr3 = new FriendRequest(3, "Joe", 3);
        ArrayList<FriendRequest> frList = new ArrayList<FriendRequest>();
        frList.add(fr1);
        frList.add(fr2);
        frList.add(fr3);

        FriendRequestAdapter adapter = new FriendRequestAdapter(frList, this);
        receivedFriendRequestsList.setAdapter(adapter);

        adapter.notifyDataSetChanged();



        RecyclerView sentInvitations = (RecyclerView) findViewById(R.id.sentInvitations);
        sentInvitations.setLayoutManager(new LinearLayoutManager(this));

        // TODO: send server request:
        Invitation inv1 = new Invitation("Mino", "denied");
        Invitation inv2 = new Invitation("James", "pending");
        Invitation inv3 = new Invitation("Ivan", "accepted");
        ArrayList<Invitation> invList = new ArrayList<Invitation>();
        invList.add(inv1);
        invList.add(inv2);
        invList.add(inv3);

        InvitationAdapter invitationAdapter = new InvitationAdapter(invList, this);
        sentInvitations.setAdapter(invitationAdapter);

        invitationAdapter.notifyDataSetChanged();
    }
}