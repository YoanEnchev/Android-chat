package com.example.chat;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;

import com.example.chat.adapters.FriendRequestAdapter;
import com.example.chat.adapters.InvitationAdapter;
import com.example.chat.models.FriendRequest;
import com.example.chat.models.Invitation;
import com.example.chat.storage.MainFilesHelper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class InvitationsListing extends AppCompatActivity {

    public static InvitationsListing context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitations_listing);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView receivedFriendRequestsList = (RecyclerView) findViewById(R.id.friendsRequestList);
        receivedFriendRequestsList.setLayoutManager(new LinearLayoutManager(this));

        InvitationsListing.context = this;

        ExtractInvitations commThread = new ExtractInvitations();
        new Thread(commThread).start();

        ArrayList<FriendRequest> frList = new ArrayList<FriendRequest>();
        FriendRequestAdapter adapter = new FriendRequestAdapter(frList, this);
        receivedFriendRequestsList.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        RecyclerView sentInvitations = (RecyclerView) findViewById(R.id.sentInvitations);
        sentInvitations.setLayoutManager(new LinearLayoutManager(this));
        cdt = SocketRefreshHelper.createSocketRefresher(this, "invitations");

        ArrayList<Invitation> invList = new ArrayList<Invitation>();
        InvitationAdapter invitationAdapter = new InvitationAdapter(invList, this);
        sentInvitations.setAdapter(invitationAdapter);

        Button bLogout = (Button) findViewById(R.id.button_logout);
        bLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.LoginForm");
                startActivity(intent);

                MainFilesHelper.writeToFile("user-info.json", "{}", InvitationsListing.context);
            }
        });
    }

    public CountDownTimer cdt;

    public void updateInvitations(JSONArray invs) {

        try {
            ArrayList<Invitation> invitations = new ArrayList<>();
            ArrayList<FriendRequest> friendRequests = new ArrayList<>();

            for (int i = 0; i < invs.length(); i++) {
                JSONObject jsonInv = (JSONObject) invs.get(i);

                int id = jsonInv.getInt("invitationID");

                String statusString = "pending";
                int statusInt = jsonInv.getInt("status");

                if(statusInt == Invitation.STATUS_ACCEPTED) {
                    statusString = "accepted";
                }
                else if(statusInt == Invitation.STATUS_DENIED) {
                    statusString = "denied";
                }

                JSONObject senderData = jsonInv.getJSONObject("sender");
                int senderID = senderData.getInt("senderID");
                String senderName = senderData.getString("name");


                JSONObject receiverData = jsonInv.getJSONObject("reciever");
                int receiverID = receiverData.getInt("receiverID");
                String receiverName = receiverData.getString("name");

                int userID = MainFilesHelper.getUserID(context);

                if(receiverID == userID) {
                    if(statusString.equals("pending")) {
                        FriendRequest fr = new FriendRequest(id, senderName, senderID);
                        friendRequests.add(fr);
                    }
                }
                else {
                    Invitation inv = new Invitation(receiverName, statusString);
                    invitations.add(inv);
                }
            }

            InvitationAdapter.adapterContext.invitations = invitations;
            InvitationAdapter.adapterContext.notifyDataSetChanged();

            FriendRequestAdapter.adapterContext.friendRequests = friendRequests;
            FriendRequestAdapter.adapterContext.notifyDataSetChanged();

        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void onDestroy() {
        super.onDestroy();

        cdt.cancel();
    }

    static class ExtractInvitations implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.EXTRACT_INVITATIONS);
                regData.put("userID", MainFilesHelper.getUserID(context));

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}