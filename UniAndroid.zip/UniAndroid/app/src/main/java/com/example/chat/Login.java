package com.example.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chat.sharedViewModels.LoginRegisterForms;
import com.example.chat.storage.MainFilesHelper;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button bLogin;
    EditText etUsername, etPassword;
    TextView etGoToRegister, usernameMessage, passwordMessage;
    static Login context;

    private static String filledUsername;
    private static String filledPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        bLogin = (Button) findViewById(R.id.bLogin);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etGoToRegister = (TextView) findViewById(R.id.registerLink);
        usernameMessage = (TextView) findViewById(R.id.usernameMessage);
        passwordMessage = (TextView) findViewById(R.id.passwordMessage);

        bLogin.setOnClickListener(this);
        etGoToRegister.setOnClickListener(this);

        Login.context = this; // ненормална работа просто...
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bLogin:
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                filledUsername = username.trim();
                filledPassword = password.trim();

                String usernameErrorMsg = LoginRegisterForms.isUsernameValid(username);
                String passwordErrorMsg = LoginRegisterForms.isPasswordValid(password);

                usernameMessage.setText(usernameErrorMsg);
                passwordMessage.setText(passwordErrorMsg);

                LoginAttempt commThread = new LoginAttempt();
                new Thread(commThread).start();
                break;

            case R.id.registerLink:

                Intent intent = new Intent("android.intent.action.RegsterForm");
                startActivity(intent);
                break;
        }
    }

    public void handleSuccessfulLogin(int userID) {

        runOnUiThread(() -> {
            try {
                JSONObject userInfoObj = new JSONObject();
                userInfoObj.put("username", Login.filledUsername);
                userInfoObj.put("id", userID);
                MainFilesHelper.writeToFile("user-info.json", userInfoObj.toString(), Login.context);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }

            Intent intent = new Intent("android.intent.action.ChatsListing");
            startActivity(intent);
        });
    }


    class LoginAttempt implements Runnable {

        @Override
        public void run() {
            Log.d("xx", "LoginAttempt");
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject loginData = new JSONObject();
                loginData.put("requestType", SocketHelper.LOGIN);
                loginData.put("name", Login.filledUsername);
                loginData.put("password", Login.filledPassword);

                String data = loginData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}