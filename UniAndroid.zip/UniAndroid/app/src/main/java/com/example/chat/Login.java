package com.example.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chat.sharedViewModels.LoginRegisterForms;
import com.example.chat.storage.MainFilesHelper;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button bLogin;
    EditText etUsername, etPassword;
    TextView etGoToRegister, usernameMessage, passwordMessage;
    Activity context = this;

    private String filledUsername;
    private String filledPassword;
    private Socket socket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        bLogin = (Button) findViewById(R.id.bLogin);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etGoToRegister = (TextView) findViewById(R.id.registerLink);
        usernameMessage = (TextView) findViewById(R.id.usernameMessage);
        passwordMessage = (TextView) findViewById(R.id.passwordMessage);

        bLogin.setOnClickListener(this);
        etGoToRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bLogin:
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                filledUsername = username.trim();
                filledPassword = password.trim();

                String usernameErrorMsg = LoginRegisterForms.isUsernameValid(username);
                String passwordErrorMsg = LoginRegisterForms.isPasswordValid(password);

                usernameMessage.setText(usernameErrorMsg);
                passwordMessage.setText(passwordErrorMsg);

                //runOnUiThread(() -> {
                Log.d("xx", "start task");

                    //LoginAttemptTask b = new LoginAttemptTask();
                    //b.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
            /*
            // Run operation here
            */
                        // After getting the result
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                LoginAttemptTask b = new LoginAttemptTask();
                                //b.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                                b.execute();
                            }
                        });
                    }
                }).start();
                //});

                LoginAttempt commThread = new LoginAttempt();
                new Thread(commThread).start();
                break;

            case R.id.registerLink:

                Intent intent = new Intent("android.intent.action.RegsterForm");
                startActivity(intent);
                break;
        }
    }



    class LoginAttemptTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            runOnUiThread(() -> {
                try {
                    Log.d("xx", "login");

                    //SocketHelper.socket = new java.net.Socket(InetAddress.getByName(getString(R.string.server_host)), Integer.parseInt(getString(R.string.server_port)));
                    DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());
                    String data = "POST /WHATAREWEDOING HTTP/1.1\r\nHost: 418a-95-42-121-24.ngrok.io\r\nUser-Agent: VladoFox\r\nAccept: */*\r\n\r\nd";
                    byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                    out.write(dataInBytes);
                    out.flush();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Log.d("xxx", "greshka login");
                }
            });


            return "";
        }
    }

    class LoginAttempt implements Runnable {

        @Override
        public void run() {
            try {
                Log.d("xx", "login xyz");

                SocketHelper.socket = new java.net.Socket(InetAddress.getByName(getString(R.string.server_host)), Integer.parseInt(getString(R.string.server_port)));
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());
                String data = "POST /WHATAREWEDOING HTTP/1.1\r\nHost: 418a-95-42-121-24.ngrok.io\r\nUser-Agent: VladoFox\r\nAccept: */*\r\n\r\nd";
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("xxx", "greshka login");
            }
        }
    }
}