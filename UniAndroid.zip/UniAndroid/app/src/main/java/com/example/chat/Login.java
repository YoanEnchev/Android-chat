package com.example.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chat.sharedViewModels.LoginRegisterForms;
import com.example.chat.storage.MainFilesHelper;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONException;
import org.json.JSONObject;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button bLogin;
    EditText etUsername, etPassword;
    TextView etGoToRegister, usernameMessage, passwordMessage;
    Activity context = this;

    private String filledUsername;
    private String filledPassword;
    private Socket socket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        bLogin = (Button) findViewById(R.id.bLogin);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etGoToRegister = (TextView) findViewById(R.id.registerLink);
        usernameMessage = (TextView) findViewById(R.id.usernameMessage);
        passwordMessage = (TextView) findViewById(R.id.passwordMessage);

        bLogin.setOnClickListener(this);
        etGoToRegister.setOnClickListener(this);

        try {

            socket = IO.socket(getString(R.string.server_host) + "/login");
            socket.on("login-response", loginResponse);
            socket.connect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bLogin:
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                filledUsername = username.trim();
                filledPassword = password.trim();

                String usernameErrorMsg = LoginRegisterForms.isUsernameValid(username);
                String passwordErrorMsg = LoginRegisterForms.isPasswordValid(password);

                usernameMessage.setText(usernameErrorMsg);
                passwordMessage.setText(passwordErrorMsg);

                if(usernameErrorMsg.length() == 0 && passwordErrorMsg.length() == 0) {
                    socket.emit("login", filledUsername, filledPassword);
                }
                break;

            case R.id.registerLink:
                Intent intent = new Intent("android.intent.action.RegsterForm");
                startActivity(intent);
                break;
        }
    }

    private Emitter.Listener loginResponse = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(() -> {

                int responseId = 0;
                Log.d("zz", "message:: " + java.util.Arrays.toString(args));


                if(responseId == 0) {
                    Toast.makeText(context, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                    return;
                }

                JSONObject userInfoObj = new JSONObject();

                try {
                    userInfoObj.put("id", responseId); // TODO: replace with response result.
                    userInfoObj.put("username", filledUsername);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                MainFilesHelper.writeToFile("user-info.json", userInfoObj.toString(), context);

                Intent intent = new Intent("android.intent.action.ChatsListing");
                startActivity(intent);
            });
        }
    };
}