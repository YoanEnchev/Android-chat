package com.example.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.chat.sharedViewModels.LoginRegisterForms;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button bLogin;
    EditText etUsername, etPassword;
    TextView etGoToRegister, usernameMessage, passwordMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        bLogin = (Button) findViewById(R.id.bLogin);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etGoToRegister = (TextView) findViewById(R.id.registerLink);
        usernameMessage = (TextView) findViewById(R.id.usernameMessage);
        passwordMessage = (TextView) findViewById(R.id.passwordMessage);

        bLogin.setOnClickListener(this);
        etGoToRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bLogin:
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                String usernameErrorMsg = LoginRegisterForms.isUsernameValid(username);
                String passwordErrorMsg = LoginRegisterForms.isPasswordValid(password);

                usernameMessage.setText(usernameErrorMsg);
                passwordMessage.setText(passwordErrorMsg);

                if(usernameErrorMsg.length() == 0 && passwordErrorMsg.length() == 0) {
                    // TODO: send a request to server and analyze it's response

                    Intent intent = new Intent("android.intent.action.ChatsListing");
                    startActivity(intent);
                }
                break;

            case R.id.registerLink:
                Intent intent = new Intent("android.intent.action.RegsterForm");
                startActivity(intent);
                break;
        }
    }
}