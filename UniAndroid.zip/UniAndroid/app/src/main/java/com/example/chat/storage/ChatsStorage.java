package com.example.chat.storage;

import android.app.Activity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ChatsStorage {

    public static void addDummyItems(Activity context) throws JSONException {

        JSONArray chats = new JSONArray();
        int messageId = 1;

        for(int i = 1; i <= 10; i++) {

            JSONArray messages = new JSONArray();

            for(int j = 1; j < 20; j++) {
                JSONObject message = new JSONObject();

                message.put("id", messageId);
                message.put("message", "some message " + messageId);
                message.put("date", "06-12-2021");
                message.put("sender_username", "Alice " + i);
                message.put("sender_id", i);
                message.put("username", "Alice");

                messageId++;
                messages.put(message);
            }

            JSONObject chat = new JSONObject();
            chat.put("id", i);
            chat.put("name", "Chat " + i);
            chats.put(chat);

            MainFilesHelper.writeToFile("messages_" + i + ".json", messages.toString(), context);
        }

        MainFilesHelper.writeToFile("chats.json", chats.toString(), context);
    }
}
