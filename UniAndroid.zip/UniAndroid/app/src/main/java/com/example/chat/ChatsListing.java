package com.example.chat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.chat.adapters.ChatItemsAdapter;
import com.example.chat.models.Chat;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class ChatsListing extends AppCompatActivity {

    private RecyclerView chatsList;
    private  ChatItemsAdapter adapter;
    private FloatingActionButton invitationsButton;
    private FloatingActionButton addFriendButton;

    public static ChatsListing context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chats_listing);

        chatsList = (RecyclerView) findViewById(R.id.chatList);
        chatsList.setLayoutManager(new LinearLayoutManager(this));

        invitationsButton = (FloatingActionButton) findViewById(R.id.invitions);
        addFriendButton = (FloatingActionButton) findViewById(R.id.addFriend);

        ArrayList<Chat> chats = new ArrayList<Chat>();

        String chatsStr = MainFilesHelper.readFile("chats.json", this);
        try {
            JSONArray chatsArr = new JSONArray(chatsStr);

            // Load from local files if serve is not available:
            for(int i = 0; i < chatsArr.length(); i++) {
                JSONObject jsonObj = (JSONObject) chatsArr.get(i);
                int id = jsonObj.getInt("id");
                String name = jsonObj.getString("name");

                Chat chat = new Chat(id, name);
                chats.add(chat);
            }

            adapter = new ChatItemsAdapter(chats, this);
            chatsList.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        context = this;

        invitationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.InvitationsListing");
                startActivity(intent);
            }
        });

        addFriendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.SearchUsers");
                startActivity(intent);
            }
        });

        ChatsListing.ExtractChats commThread = new ChatsListing.ExtractChats();
        new Thread(commThread).start();
    }


    public void updateChats(JSONArray chatsArr) {

        ArrayList<Chat> chats = new ArrayList<Chat>();

        try {

            // Load from local files if serve is not available:
            for (int i = 0; i < chatsArr.length(); i++) {
                JSONObject jsonObj = (JSONObject) chatsArr.get(i);
                int id = jsonObj.getInt("id");
                String name = jsonObj.getString("name");

                Chat chat = new Chat(id, name);
                chats.add(chat);
            }

            adapter.chats = chats;
            adapter.notifyDataSetChanged();
        }
        catch (Exception ex) {

        }
    }

    static class ExtractChats implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.EXTRACT_CHATS);
                regData.put("user-id", MainFilesHelper.getUserID(ChatsListing.context));

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}