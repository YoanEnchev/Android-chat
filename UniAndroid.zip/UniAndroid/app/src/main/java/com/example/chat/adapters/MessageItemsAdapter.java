package com.example.chat.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.style.BackgroundColorSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.EditMessage;
import com.example.chat.OpenedChat;
import com.example.chat.R;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;

import java.util.ArrayList;

public class MessageItemsAdapter extends RecyclerView.Adapter<MessageItemsAdapter.ViewHolder>{
    public static ArrayList<Message> messages;
    public static Activity activityContext = null;
    private Context context;

    public MessageItemsAdapter(ArrayList<Message> messagesArr, Context context) {
        messages = messagesArr;
        this.context = context;
    }

    @Override
    public MessageItemsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.message_item, parent, false);

        return new MessageItemsAdapter.ViewHolder(v);
    }

    @SuppressLint("RtlHardcoded")
    @Override
    public void onBindViewHolder(@NonNull MessageItemsAdapter.ViewHolder holder, int position) {

        Message message = messages.get(position);
        holder.messageTextView.setText(message.getText());
        holder.usernameTextView.setText(message.getUsername());

        if(message.getUserId() == MainFilesHelper.getUserID(activityContext)) {
            ((RelativeLayout.LayoutParams) holder.messageLayout.getLayoutParams()).removeRule(RelativeLayout.LEFT_OF);
            holder.messageTextView.setBackgroundColor(Color.BLACK);
        }
        else {
            ((RelativeLayout.LayoutParams) holder.messageLayout.getLayoutParams()).addRule(RelativeLayout.LEFT_OF, holder.messageAlignTarget.getId());
            holder.messageTextView.setBackgroundColor(Color.parseColor("#8e54e9"));
        }

        holder.messageTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(message.getUserId() != MainFilesHelper.getUserID(OpenedChat.context)) return;

                Intent intent = new Intent("android.intent.action.EditMessage");
                context.startActivity(intent);

                EditMessage.chatID = OpenedChat.openedChatID;
                EditMessage.messageID = message.getId();
                EditMessage.messageText = message.getText();
            }
        });
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView messageTextView;
        public LinearLayout messageLayout;
        public TextView messageAlignTarget;
        public TextView usernameTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            messageTextView = (TextView) itemView.findViewById(R.id.message);
            messageLayout = (LinearLayout) itemView.findViewById(R.id.messageLayout);
            messageAlignTarget = (TextView) itemView.findViewById(R.id.userHead);
            usernameTextView = (TextView) itemView.findViewById(R.id.username);
        }
    }
}
