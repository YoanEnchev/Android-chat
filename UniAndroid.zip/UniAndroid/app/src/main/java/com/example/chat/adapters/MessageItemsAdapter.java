package com.example.chat.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.R;
import com.example.chat.models.Message;

import java.util.ArrayList;

public class MessageItemsAdapter extends RecyclerView.Adapter<MessageItemsAdapter.ViewHolder>{
    ArrayList<Message> messages;
    private Context context;

    public MessageItemsAdapter(ArrayList<Message> messages, Context context) {
        this.messages = messages;
        this.context = context;
    }

    @Override
    public MessageItemsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.message_item, parent, false);

        return new MessageItemsAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageItemsAdapter.ViewHolder holder, int position) {
        Message message = messages.get(position);

        holder.messageTextView.setText(message.getText());
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView messageTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            messageTextView = (TextView) itemView.findViewById(R.id.message);
        }
    }
}
