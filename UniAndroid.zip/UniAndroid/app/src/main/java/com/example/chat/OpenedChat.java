package com.example.chat;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.example.chat.adapters.ChatItemsAdapter;
import com.example.chat.adapters.MessageItemsAdapter;
import com.example.chat.models.Chat;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class OpenedChat extends AppCompatActivity {

    public static RecyclerView messagesList;
    private MessageItemsAdapter adapter;
    private EditText textboxMessage;
    private Button sendButton;
    private Button uploadFileButton;
    private Button addMember;

    public static OpenedChat context;

    private static final int FILE_SELECT_CODE = 44646464;

    public static int openedChatID = 0;
    private static String messageToSent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opened_chat);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textboxMessage = findViewById(R.id.textboxMessage);
        sendButton = findViewById(R.id.button_send_message);
        uploadFileButton = findViewById(R.id.uploadFile);
        addMember = findViewById(R.id.add_member);

        Activity that = this;


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String messageText = textboxMessage.getText().toString();

                if(messageText.length() > 0) {
                    messageToSent = messageText;

                    SendMessage commThread = new SendMessage();
                    new Thread(commThread).start();

                    // Message message = new Message(1, textboxMessage.getText().toString(), "", MainFilesHelper.getUsername(that), MainFilesHelper.getUserID(that));
                    // addMessage(message);

                    textboxMessage.setText("");
                }
            }
        });

        uploadFileButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                try {
                    startActivityForResult(
                            Intent.createChooser(intent, "Select a File to Upload"),
                            FILE_SELECT_CODE);
                } catch (android.content.ActivityNotFoundException ex) {
                    // Potentially direct the user to the Market with a Dialog
                    Toast.makeText(that, "Please install a File Manager.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });


        addMember.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.AddUserToGroup");
                context.startActivity(intent);
            }
        });

        messagesList = (RecyclerView) findViewById(R.id.messagesList);
        messagesList.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Message> messages = new ArrayList<Message>();
        String messageStr = MainFilesHelper.readFile("messages_" + openedChatID + ".json", this);

        try {
            JSONArray messagesArr = new JSONArray(messageStr);

            for(int i = 0; i < messagesArr.length(); i++) {
                JSONObject jsonObj = (JSONObject) messagesArr.get(i);
                int id = jsonObj.getInt("id");
                String text = jsonObj.getString("message");
                String date = jsonObj.getString("date");
                String senderUsername = jsonObj.getString("sender_username");
                int senderID = jsonObj.getInt("sender_id");

                Message message = new Message(id, text, date, senderUsername, senderID);
                messages.add(message);
            }

            MessageItemsAdapter.activityContext = this;
            adapter = new MessageItemsAdapter(messages, this);

            messagesList.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(messages.size() > 1) {
            messagesList.scrollToPosition(messages.size() - 1);
        }

        OpenedChat.context = this;
    }

    public void receiveMessage(int chatID, JSONObject jsonObj) {
        if(OpenedChat.openedChatID == chatID) {

            try {
                int id = jsonObj.getInt("id");
                String text = jsonObj.getString("message");
                String date = jsonObj.getString("date");
                String username = jsonObj.getString("sender_username");
                int userID = jsonObj.getInt("sender_id");

                Message message = new Message(id, text, date, username, userID);
                addMessage(message);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void addMessage(Message message) {
        MessageItemsAdapter.messages.add(message);
        adapter.notifyItemInserted(MessageItemsAdapter.messages.size() - 1);
        messagesList.scrollToPosition(adapter.getItemCount() - 1);

        // update local file:
        String messageStr = MainFilesHelper.readFile("messages_" + openedChatID + ".json", this);

        try {
            JSONArray messagesArr = new JSONArray(messageStr);

            JSONObject jsonObj = new JSONObject();
            jsonObj.put("id", message.getId());
            jsonObj.put("message", message.getText());
            jsonObj.put("date", message.getDate());
            jsonObj.put("sender_username", message.getUsername());
            jsonObj.put("sender_id", message.getUserId());

            messagesArr.put(jsonObj);
            MainFilesHelper.writeToFile("messages_" + openedChatID + ".json", messagesArr.toString(), this);

            OpenedChat.context.updateMessages(messagesArr);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void updateSingleMessage(int chatID, JSONObject jsonObj) {

        if(OpenedChat.openedChatID == chatID) {

            try {
                int messageID = jsonObj.getInt("id");
                String newText = jsonObj.getString("message");

                // update local file:
                String messageStr = MainFilesHelper.readFile("messages_" + chatID + ".json", this);


                JSONArray messagesArrOld = new JSONArray(messageStr);
                JSONArray messagesArrNew = new JSONArray();

                for(int i = 0; i < messagesArrOld.length(); i++) {
                    JSONObject jsonObjMessage = (JSONObject) messagesArrOld.get(i);

                    if(jsonObjMessage.getInt("id") == messageID) {
                        jsonObjMessage.put("message", newText);
                    }

                    messagesArrNew.put(jsonObjMessage);
                }

                MainFilesHelper.writeToFile("messages_" + chatID + ".json", messagesArrNew.toString(), this);

                // update recycler view.

                for(int i = 0; i < MessageItemsAdapter.messages.size(); i++) {
                    if(MessageItemsAdapter.messages.get(i).getId() == messageID) {
                        MessageItemsAdapter.messages.get(i).setText(newText);
                    }
                }

                adapter.notifyDataSetChanged();


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }




    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    // Get the Uri of the selected file
                    Uri uri = data.getData();
                    try {

                        Scanner s = new Scanner(getContentResolver().openInputStream(uri)).useDelimiter("\\A");
                        String result = s.hasNext() ? s.next() : "";

                        Log.d("zz", result);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

                    StringBuilder fileContent = new StringBuilder();
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void onBackPressed() {

        Intent intent = new Intent("android.intent.action.ChatsListing");
        startActivity(intent);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        finish();
        startActivity(intent);
    }

    public String getPath(Uri uri) {

        String path = null;
        String[] projection = { MediaStore.Files.FileColumns.DATA };
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);

        if(cursor == null){
            path = uri.getPath();
        }
        else{
            cursor.moveToFirst();
            int column_index = cursor.getColumnIndexOrThrow(projection[0]);
            path = cursor.getString(column_index);
            cursor.close();
        }

        return ((path == null || path.isEmpty()) ? (uri.getPath()) : path);
    }

    public void updateMessages(JSONArray messagesArr) {

        ArrayList<Message> messages = new ArrayList<Message>();

        try {

            // Load from local files if serve is not available:
            for (int i = 0; i < messagesArr.length(); i++) {
                JSONObject jsonObj = (JSONObject) messagesArr.get(i);
                int id = jsonObj.getInt("id");
                String text = jsonObj.getString("message");
                String date = jsonObj.getString("date");
                String username = jsonObj.getString("sender_username");
                int userID = jsonObj.getInt("sender_id");

                Message message = new Message(id, text, date, username, userID);
                messages.add(message);
            }

            MessageItemsAdapter.messages = messages;
            adapter.notifyDataSetChanged();
        }
        catch (Exception ex) {

        }
    }

    class SendMessage implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.SEND_MESSAGE);
                regData.put("text", OpenedChat.messageToSent);
                regData.put("user", MainFilesHelper.getUserID(context));
                regData.put("chatID", OpenedChat.openedChatID);

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}