package com.example.chat;

import android.os.Bundle;

import com.example.chat.adapters.ChatItemsAdapter;
import com.example.chat.adapters.MessageItemsAdapter;
import com.example.chat.models.Chat;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class OpenedChat extends AppCompatActivity {

    private RecyclerView messagesList;
    private RecyclerView.Adapter adapter;
    private EditText textboxMessage;
    private Button sendButton;

    public static int openedChatID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opened_chat);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textboxMessage = findViewById(R.id.textboxMessage);
        sendButton = findViewById(R.id.button_send_message);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String messageText = textboxMessage.getText().toString();

                if(messageText.length() > 0) {
                    Message message = new Message(1, textboxMessage.getText().toString(), "", "Alice", 2);
                    // TODO: send request
                    addMessage(message);
                }
            }
        });


        /*
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        */

        messagesList = (RecyclerView) findViewById(R.id.messagesList);
        messagesList.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Message> messages = new ArrayList<Message>();
        String messageStr = MainFilesHelper.readFile("messages_" + openedChatID + ".json", this);

        try {
            JSONArray messagesArr = new JSONArray(messageStr);

            for(int i = 0; i < messagesArr.length(); i++) {
                JSONObject jsonObj = (JSONObject) messagesArr.get(i);
                int id = jsonObj.getInt("id");
                String text = jsonObj.getString("message");
                String date = jsonObj.getString("date");
                String senderUsername = jsonObj.getString("sender_username");
                int senderID = jsonObj.getInt("sender_id");

                Message message = new Message(id, text, date, senderUsername, senderID);
                messages.add(message);
            }

            adapter = new MessageItemsAdapter(messages, this);
            messagesList.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void addMessage(Message message) {
        MessageItemsAdapter.messages.add(message);
        adapter.notifyItemInserted(MessageItemsAdapter.messages.size() - 1);
        messagesList.scrollToPosition(adapter.getItemCount() - 1);

        // update local file:
        String messageStr = MainFilesHelper.readFile("messages_" + openedChatID + ".json", this);

        try {
            JSONArray messagesArr = new JSONArray(messageStr);

            JSONObject jsonObj = new JSONObject();
            jsonObj.put("id", message.getId());
            jsonObj.put("message", message.getText());
            jsonObj.put("date", message.getDate());
            jsonObj.put("sender_username", message.getUsername());
            jsonObj.put("sender_id", message.getUserId());

            messagesArr.put(jsonObj);
            MainFilesHelper.writeToFile("messages_" + openedChatID + ".json", messagesArr.toString(), this);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}