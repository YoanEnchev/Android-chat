package com.example.chat;

import android.os.Bundle;

import com.example.chat.adapters.ChatItemsAdapter;
import com.example.chat.adapters.MessageItemsAdapter;
import com.example.chat.models.Chat;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class OpenedChat extends AppCompatActivity {

    private RecyclerView messagesList;
    private RecyclerView.Adapter adapter;

    public static int openedChatID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opened_chat);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        /*
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        */

        messagesList = (RecyclerView) findViewById(R.id.messagesList);
        messagesList.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Message> messages = new ArrayList<Message>();
        int correspondentID = 1; // TODO: pass it somehow
        String messageStr = MainFilesHelper.readFile("messages_" + correspondentID + ".json", this);

        try {
            JSONArray messagesArr = new JSONArray(messageStr);

            for(int i = 0; i < messagesArr.length(); i++) {
                JSONObject jsonObj = (JSONObject) messagesArr.get(i);
                int id = jsonObj.getInt("id");
                String text = jsonObj.getString("message");
                String date = jsonObj.getString("date");
                String senderUsername = jsonObj.getString("sender_username");
                int senderID = jsonObj.getInt("sender_id");

                Message message = new Message(id, text, date, senderUsername, senderID);
                messages.add(message);
            }
Log.d("aaaa", messages.size() + "");
            adapter = new MessageItemsAdapter(messages, this);
            messagesList.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}