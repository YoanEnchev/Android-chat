package com.example.chat;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.chat.storage.ChatsStorage;
import com.example.chat.storage.MainFilesHelper;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    public static Socket mSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String chatsListingFile = "chats.json";
        if (!MainFilesHelper.fileExist(chatsListingFile, this)) {
            JSONArray chatsArr = new JSONArray();
            MainFilesHelper.writeToFile(chatsListingFile, chatsArr.toString(), this);
        }

        String userInfoFile = "user-info.json";
        if (!MainFilesHelper.fileExist(userInfoFile, this)) {
            JSONObject userInfoObj = new JSONObject();
            MainFilesHelper.writeToFile(userInfoFile, userInfoObj.toString(), this);

            // TODO: remove it
            try {
                ChatsStorage.addDummyItems(this);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        JSONObject userInfoObj = null;
        try {
            userInfoObj = new JSONObject(MainFilesHelper.readFile(userInfoFile, this));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String intStr = "android.intent.action.RegsterForm";

        if (userInfoObj.has("id")) {
            intStr = "android.intent.action.ChatsListing";
        }

        Intent intent = new Intent(intStr);
        startActivity(intent);

        try {
            mSocket = IO.socket(
                    //getString(R.string.server_host), Integer.parseInt(getString(R.string.server_port))
                    "https://418a-95-42-121-24.ngrok.io/"
                    //"https://socketio-chat-h9jt.herokuapp.com"
            );

        } catch (Exception e) {
            e.printStackTrace();
        }

        //BackgroundTask b = new BackgroundTask();
        //b.execute("");

        //websocketConnection();

        BackgroundTask b = new BackgroundTask();
        b.execute();
    }

    private void websocketConnection() {
        //Get websocket from application

        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.on("messageFromServer", onNewLocation);
        mSocket.on("", emptySomething);

        mSocket.on(Socket.EVENT_MESSAGE, someMessage);
        //mSocket.on(Socket., someMessage);


        mSocket.on("new message", receivedMessage);
        mSocket.on("successful login", receivedMessage);
        mSocket.connect();

        // Send message to server.
        mSocket.emit("new message", "from-app-2", "ss");
    }


    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(() -> {

            });
        }
    };

    private Emitter.Listener onDisconnect = args -> runOnUiThread(() -> {

    });

    private Emitter.Listener onConnectError = args -> runOnUiThread(() -> {
         /*   Toast.makeText(getApplicationContext(),
            R.string.error_connect, Toast.LENGTH_LONG).show()*/
    });

    private Emitter.Listener onNewLocation = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(() -> {
                Log.d("zz", "aa");

            });
        }
    };

    private Emitter.Listener emptySomething = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(() -> {
                Log.d("zz", "aaaaaa");

            });
        }
    };


    private Emitter.Listener receivedMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(() -> {
                Log.d("zz", "message:: " + java.util.Arrays.toString(args));
            });

            // Instantiate the RequestQueue.
            /*
            RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
            String url ="https://www.google.com";

            // Request a string response from the provided URL.
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });

// Add the request to the RequestQueue.
            queue.add(stringRequest);
            queue.start(); // maybe not needed?

             */
        }
    };

    private Emitter.Listener someMessage = new Emitter.Listener() {

        @Override
        public void call(Object... args) {
            Log.d("zz", "something");
        }
    };

    class BackgroundTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            /*
            try {
                java.net.Socket s = new java.net.Socket(InetAddress.getByName("418a-95-42-121-24.ngrok.io"), 443 );
                Log.d("xxx", "!!!!" + "here");

                DataOutputStream out = new DataOutputStream(s.getOutputStream());
                out.writeUTF("xxxx");
                out.flush();

                Log.d("xxx", "!!!!" + "here 2");

                DataInputStream in = new DataInputStream(s.getInputStream());
                String aa = in.readUTF();
                Log.d("xxx", "!!!!" + aa);

            } catch (IOException e) {
                e.printStackTrace();
            }*/

            try {
                java.net.Socket socket = null;

                socket = new java.net.Socket(InetAddress.getByName("418a-95-42-121-24.ngrok.io"), 80);

                Log.d("xxx", "Connected to server ...");
                // DataInputStream in = new DataInputStream(System.in);
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());

                // char type = 'A';
                //String data = "POST /WHATAREWEDOING HTTP/1.1\r\nHost: 418a-95-42-121-24.ngrok.io\r\nUser-Agent: VladoFox\r\nAccept: */*\r\n\r\ndasndjsdhjsdj super sexy data";
                String data = "POST /WHATAREWEDOING HTTP/1.1\r\nHost: 418a-95-42-121-24.ngrok.io\r\nUser-Agent: VladoFox\r\nAccept: */*\r\n\r\nd";

                // int length = data.length();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                // out.writeChar(type);
                // out.writeInt(length);
                out.write(dataInBytes);
                out.flush();

                Log.d("xxx", "Sent data to server");
                // length = in.readInt();
                Log.d("xxx", "Data read from server");
                // StringBuffer a = ServerReadFromClient(length, in);

                DataInputStream in = new DataInputStream(socket.getInputStream());

                /*while (true) {
                    String readData = in.readUTF();
                    Log.d("xx", readData);
                }*/

                // Not sure about length yet.
                int length = data.length();

                byte[] msgBuffer = new byte[length]; // Буфер за съобщението
                int bytesRead = 0; // Брой прочетени байта
                boolean hasBuffer = true; // Очакващ патент "Има-ли-още-данни" флаг

                // Правим стринг, не по-голям от очакваната дължина
                StringBuffer dataString = new StringBuffer(length);

                while (hasBuffer) {
                    // цикъл, в който четем
                    int byteToRead;
                    try {
                        byteToRead = in.read(msgBuffer); // Четем в буфера
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                    bytesRead = byteToRead + bytesRead;

                    if (bytesRead <= length) {
                        dataString.append(new String(msgBuffer, 0, byteToRead, StandardCharsets.UTF_8));
                    } else {
                        dataString.append(new String(msgBuffer, 0, length - bytesRead + byteToRead, StandardCharsets.UTF_8));
                    }

                    // Ако прочетеното е >= дължината, край
                    if (dataString.length() >= length) {
                        hasBuffer = false;
                    }
                }

                // System.out.println(a.toString());
                //socket.close();
                //out.close();
                // in.close();

                Log.d("xx_______", dataString.toString());


            }
            catch (Exception ex) {
                ex.printStackTrace();
                Log.d("xxx", "greshka");
            }


            return "";
        }
    }
}