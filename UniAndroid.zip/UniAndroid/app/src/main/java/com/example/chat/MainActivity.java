package com.example.chat;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;

import com.example.chat.storage.ChatsStorage;
import com.example.chat.storage.MainFilesHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String chatsListingFile = "chats.json";
        if(!MainFilesHelper.fileExist(chatsListingFile, this)) {
            JSONArray chatsArr = new JSONArray();
            MainFilesHelper.writeToFile(chatsListingFile, chatsArr.toString(), this);
        }

        String userInfoFile = "user-info.json";
        if(!MainFilesHelper.fileExist(userInfoFile, this)) {
            JSONObject userInfoObj = new JSONObject();
            MainFilesHelper.writeToFile(userInfoFile, userInfoObj.toString(), this);
        }

        if(false) {
            try {
                ChatsStorage.addDummyItems(this);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Intent intent = new Intent("android.intent.action.RegsterForm");
        startActivity(intent);
    }
}