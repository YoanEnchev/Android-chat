package com.example.chat;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;

import android.util.Log;
import android.widget.Toast;

import com.example.chat.adapters.InvitationAdapter;
import com.example.chat.models.Invitation;
import com.example.chat.storage.Storage;
import com.example.chat.storage.MainFilesHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    Activity context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String chatsListingFile = "chats.json";
        if (!MainFilesHelper.fileExist(chatsListingFile, this)) {
            JSONArray chatsArr = new JSONArray();
            MainFilesHelper.writeToFile(chatsListingFile, chatsArr.toString(), this);
        }

        String userInfoFile = "user-info.json";
        if (!MainFilesHelper.fileExist(userInfoFile, this)) {
            JSONObject userInfoObj = new JSONObject();
            MainFilesHelper.writeToFile(userInfoFile, userInfoObj.toString(), this);

            // TODO: remove it
            /*try {
                Storage.addDummyItems(this);
            } catch (JSONException e) {
                e.printStackTrace();
            }*/
        }

        JSONObject userInfoObj = null;
        try {
            userInfoObj = new JSONObject(MainFilesHelper.readFile(userInfoFile, this));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String intStr = "android.intent.action.RegsterForm";

        if (userInfoObj.has("id")) {
            intStr = "android.intent.action.ChatsListing";
        }

        Intent intent = new Intent(intStr);
        startActivity(intent);

        BackgroundTask b = new BackgroundTask();
        b.execute();
    }

    class BackgroundTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                SocketHelper.socket = new java.net.Socket(InetAddress.getByName(getString(R.string.server_host)), Integer.parseInt(getString(R.string.server_port)));

                Log.d("xxx", "Connected to server ...");
                DataInputStream in = new DataInputStream(SocketHelper.socket.getInputStream());
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());


                Log.d("xxx", "sent something now read ...");

                Log.d("xxx", "Sent data to server");
                Log.d("xxx", "Data read from server");


                while(true) {
                    byte[] dataInBytes = new byte[1000000];
                    in.read(dataInBytes);

                    runOnUiThread(() -> {
                        try {
                            String s = new String(dataInBytes, StandardCharsets.UTF_8).trim();
                            JSONObject obj = new JSONObject(s);
                            Log.d("xxx____", obj.toString());

                            switch (obj.getInt("requestType")) {
                                case SocketHelper.LOGIN:

                                    int id = obj.getInt("id");

                                    if (id == 0) {
                                        // Failed login:
                                        Toast.makeText(context, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Login.context.handleSuccessfulLogin(id);
                                    }


                                    break;
                                case SocketHelper.REGISTER:
                                    Log.d("xx", "here");

                                    int regId = obj.getInt("id");

                                    if (regId == 0) {
                                        // Failed Register:
                                        Toast.makeText(context, "User already exists.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Log.d("xx", "here 2");
                                        Register.context.handleSuccessfulRegister(regId);
                                    }

                                    break;
                                case SocketHelper.EXTRACT_CHATS:

                                    JSONArray chatsResponse = obj.getJSONArray("chats");
                                    JSONArray chatFormated = new JSONArray();

                                    for(int i = 0; i < chatsResponse.length(); i++) {
                                        JSONObject chatResponseObj = (JSONObject) chatsResponse.get(i);

                                        JSONObject chatObjFormated = new JSONObject();
                                        chatObjFormated.put("id", chatResponseObj.getInt("chatID"));
                                        chatObjFormated.put("name", chatResponseObj.getString("chatName"));

                                        chatFormated.put(chatObjFormated);
                                    }

                                    ChatsListing.context.updateChats(chatFormated);

                                    MainFilesHelper.writeToFile("chats.json", chatFormated.toString(), context);
                                    break;
                                case SocketHelper.EXTRACT_INVITATIONS:
                                    String responseInvitations = obj.getString("invitations");

                                    JSONArray invs = new JSONArray(responseInvitations);

                                    InvitationsListing.context.updateInvitations(invs);
                                    break;
                                case SocketHelper.MODIFY_INVITATION:

                                    // If invitation activity is opened.
                                    if(InvitationsListing.context.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {

                                        InvitationsListing.ExtractInvitations commThread = new InvitationsListing.ExtractInvitations();
                                        new Thread(commThread).start();
                                    }
                                    else {
                                        int responseStatus = 2;

                                        String status = "accepted";
                                        if(responseStatus == Invitation.STATUS_DENIED) status = "denied";

                                        Toast.makeText(context, "Friend request " + status + ".", Toast.LENGTH_LONG).show();
                                    }

                                    break;
                                case SocketHelper.SEND_INVITATION: // for friendships
                                    break;
                                case SocketHelper.EXTRACT_CHAT_MESSAGES:
                                    String responseMessages = obj.getString("messages");

                                    JSONArray messagesArr = new JSONArray(responseMessages);
                                    OpenedChat.context.updateMessages(messagesArr);

                                    MainFilesHelper.writeToFile("messages_" + OpenedChat.openedChatID + ".json", responseMessages, context);

                                    break;
                                case SocketHelper.SEND_MESSAGE: // Both received and sent by the user messages
                                    int responseChatId = obj.getInt("chatID");

                                    JSONObject ob = new JSONObject(obj.getString("message"));
                                    OpenedChat.context.receiveMessage(responseChatId, ob);

                                    break;
                                case SocketHelper.EDIT_MESSAGE: // Both received and sent by the user messages
                                    int responseChatId_edit = obj.getInt("chatID");

                                    JSONObject editedMessage = new JSONObject(obj.getString("message"));
                                    OpenedChat.context.updateSingleMessage(responseChatId_edit, editedMessage);

                                    break;
                                case SocketHelper.SEARCH_USERS_FOR_INVITATION:
                                    String usersResponseForInvs = obj.getString("users");
                                    JSONArray usersResponseForInvsArr = new JSONArray(usersResponseForInvs);

                                    SearchUsers.context.updateUsersList(usersResponseForInvsArr);
                                    break;

                                case SocketHelper.SEARCH_USERS_FOR_GROUP:
                                    String usersResponseForGroup = obj.getString("users");
                                    JSONArray usersResponseForGroupArr = new JSONArray(usersResponseForGroup);

                                    AddUserToGroup.context.updateUsersList(usersResponseForGroupArr);

                                    Log.d("xx SEARCH_USERS_FOR_GROUP", "here");
                                    break;

                                case SocketHelper.CREATE_GROUP:
                                    int responseChatID_createGroup = obj.getInt("chatID");

                                    OpenedChat.openedChatID = responseChatID_createGroup;
                                    MainFilesHelper.writeToFile("message_" + responseChatID_createGroup + ".json", "[]", SearchUsers.context);

                                    Intent intent = new Intent("android.intent.action.OpenedChat");
                                    context.startActivity(intent);

                                    Log.d("xx", "CREATE_GROUP" + responseChatID_createGroup);
                                    break;
                                case SocketHelper.ADD_USER_TO_GROUP:
                                    int responseReceiverID = obj.getInt("userID");

                                    int thisUserId = MainFilesHelper.getUserID(AddUserToGroup.context);

                                     if (thisUserId == responseReceiverID &&
                                            // if chats are opened - update the list
                                            AddUserToGroup.context.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {

                                        ChatsListing.ExtractChats commThread = new ChatsListing.ExtractChats();
                                        new Thread(commThread).start();
                                    }

                                    break;
                            }
                        }
                        catch (Exception ex) {
                            Log.d("xx", "exception");

                            ex.printStackTrace();
                        }
                    });
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
                Log.d("xxx", "greshka");
            }


            return "";
        }
    }
}