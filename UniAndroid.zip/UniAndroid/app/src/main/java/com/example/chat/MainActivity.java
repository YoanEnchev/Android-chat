package com.example.chat;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.widget.Toast;

import com.example.chat.models.Invitation;
import com.example.chat.storage.Storage;
import com.example.chat.storage.MainFilesHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    Activity context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String chatsListingFile = "chats.json";
        if (!MainFilesHelper.fileExist(chatsListingFile, this)) {
            JSONArray chatsArr = new JSONArray();
            MainFilesHelper.writeToFile(chatsListingFile, chatsArr.toString(), this);
        }

        String userInfoFile = "user-info.json";
        if (!MainFilesHelper.fileExist(userInfoFile, this)) {
            JSONObject userInfoObj = new JSONObject();
            MainFilesHelper.writeToFile(userInfoFile, userInfoObj.toString(), this);

            // TODO: remove it
            /*try {
                Storage.addDummyItems(this);
            } catch (JSONException e) {
                e.printStackTrace();
            }*/
        }

        JSONObject userInfoObj = null;
        try {
            userInfoObj = new JSONObject(MainFilesHelper.readFile(userInfoFile, this));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String intStr = "android.intent.action.RegsterForm";

        if (userInfoObj.has("id")) {
            intStr = "android.intent.action.ChatsListing";
        }

        Intent intent = new Intent(intStr);
        startActivity(intent);

        BackgroundTask b = new BackgroundTask();
        b.execute();
    }

    class BackgroundTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                SocketHelper.socket = new java.net.Socket(InetAddress.getByName(getString(R.string.server_host)), Integer.parseInt(getString(R.string.server_port)));

                Log.d("xxx", "Connected to server ...");
                DataInputStream in = new DataInputStream(SocketHelper.socket.getInputStream());
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());


                Log.d("xxx", "sent something now read ...");

                Log.d("xxx", "Sent data to server");
                Log.d("xxx", "Data read from server");


                while(true) {
                    byte[] dataInBytes = new byte[1000000];
                    in.read(dataInBytes);

                    runOnUiThread(() -> {
                        try {
                            String s = new String(dataInBytes, StandardCharsets.UTF_8).trim();
                            JSONObject obj = new JSONObject(s);
                            Log.d("xxx____", obj.toString());

                            switch (obj.getInt("requestType")) {
                                case SocketHelper.LOGIN:

                                    int id = obj.getInt("id");

                                    if (id == 0) {
                                        // Failed login:
                                        Toast.makeText(context, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Login.context.handleSuccessfulLogin(id);
                                    }


                                    break;
                                case SocketHelper.REGISTER:
                                    Log.d("xx", "here");

                                    int regId = obj.getInt("id");

                                    if (regId == 0) {
                                        // Failed Register:
                                        Toast.makeText(context, "User already exists.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Log.d("xx", "here 2");
                                        Register.context.handleSuccessfulRegister(regId);
                                    }

                                    break;
                                case SocketHelper.EXTRACT_CHATS:
                                    String response = "[{\"id\":1,\"name\":\"Chat 1\"},{\"id\":2,\"name\":\"Chat 2\"}]";

                                    JSONArray chats = new JSONArray(response);
                                    ChatsListing.context.updateChats(chats);

                                    MainFilesHelper.writeToFile("chats.json", response, context);
                                    break;
                                case SocketHelper.EXTRACT_INVITATIONS:
                                    String responseInvitations = "[{\"invitetationID\":\"1\",\"status\":\"1\",\"sender\":{\"senderID\":\"2\",\"name\":\"Axial\"},\"receiver\":{\"receiverID\":\"1\",\"name\":\"Someone\"}},{\"invitetationID\":\"2\",\"status\":\"2\",\"sender\":{\"senderID\":\"1\",\"name\":\"Simeon\"},\"receiver\":{\"receiverID\":\"2\",\"name\":\"Mengetsu\"}},{\"invitetationID\":\"3\",\"status\":\"3\",\"sender\":{\"senderID\":\"1\",\"name\":\"Simeon\"},\"receiver\":{\"receiverID\":\"3\",\"name\":\"Mengetsu\"}}]";
                                    JSONArray invs = new JSONArray(responseInvitations);

                                    InvitationsListing.context.updateInvitations(invs);
                                    break;
                                case SocketHelper.MODIFY_INVITATION:
                                    int responseStatus = 2;

                                    String status = "accepted";
                                    if(responseStatus == Invitation.STATUS_DENIED) status = "denied";

                                    Toast.makeText(context, "Friend request " + status + ".", Toast.LENGTH_LONG).show();

                                    break;
                                case SocketHelper.SEND_INVITATION: // for friendships
                                    Toast.makeText(context, "Sent invitation.", Toast.LENGTH_SHORT).show();

                                    break;
                                case SocketHelper.EXTRACT_CHAT_MESSAGES:
                                    String responseMessages = "[{\"id\":1,\"message\":\"some message vvv\",\"date\":\"06-12-2021\",\"sender_username\":\"Alice 1\",\"sender_id\":1,\"username\":\"Alice\"},{\"id\":2,\"message\":\"some message 2\",\"date\":\"06-12-2021\",\"sender_username\":\"Alice 1\",\"sender_id\":2,\"username\":\"Alice\"},{\"id\":3,\"message\":\"some message 3\",\"date\":\"06-12-2021\",\"sender_username\":\"Alice 1\",\"sender_id\":1,\"username\":\"Alice\"}]";
                                    int responseChatID = 1;

                                    JSONArray messagesArr = new JSONArray(responseMessages);
                                    OpenedChat.context.updateMessages(messagesArr);

                                    MainFilesHelper.writeToFile("messages_" + responseChatID + ".json", responseMessages, context);

                                    break;
                                case SocketHelper.SEND_MESSAGE: // Both received and sent by the user messages
                                    int responseChatId = 1;

                                    // TODO: maybe add the date field?
                                    JSONObject ob = new JSONObject("{\"id\":3,\"message\":\"received message\",\"date\":\"06-12-2021\",\"sender_username\":\"Alice 1\",\"sender_id\":1,\"username\":\"Alice\"}");
                                    OpenedChat.context.receiveMessage(responseChatId, ob);

                                    break;
                                case SocketHelper.EDIT_MESSAGE: // Both received and sent by the user messages
                                    int responseChatId_edit = 1;

                                    JSONObject editedMessage = new JSONObject("{\"id\":3,\"message\":\"edited message\"}");
                                    OpenedChat.context.updateSingleMessage(responseChatId_edit, editedMessage);

                                    break;
                                case SocketHelper.SEARCH_USERS_FOR_INVITATION:
                                    String usersResponseForInvs = "[{\"name\":\"Al\", \"id\": 2}, {\"name\":\"Xsdf\", \"id\": 3}, {\"name\":\"Sop\", \"id\": 4}]";
                                    JSONArray usersResponseForInvsArr = new JSONArray(usersResponseForInvs);

                                    SearchUsers.context.updateUsersList(usersResponseForInvsArr);
                                    break;
                                case SocketHelper.SEARCH_USERS_FOR_GROUP:
                                    String usersResponseForGroup = "[{\"name\":\"Al\", \"id\": 2}, {\"name\":\"Xsdf\", \"id\": 3}, {\"name\":\"Sop\", \"id\": 4}]";
                                    JSONArray usersResponseForGroupArr = new JSONArray(usersResponseForGroup);

                                    break;

                                case SocketHelper.CREATE_GROUP:
                                    break;
                            }
                        }
                        catch (Exception ex) {
                            // TODO: Use
                            Log.d("xx", "exception");

                            ex.printStackTrace();
                        }
                    });
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
                Log.d("xxx", "greshka");
            }


            return "";
        }
    }
}