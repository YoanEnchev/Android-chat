package com.example.chat;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Looper;
import android.util.Log;
import com.example.chat.storage.ChatsStorage;
import com.example.chat.storage.MainFilesHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String chatsListingFile = "chats.json";
        if (!MainFilesHelper.fileExist(chatsListingFile, this)) {
            JSONArray chatsArr = new JSONArray();
            MainFilesHelper.writeToFile(chatsListingFile, chatsArr.toString(), this);
        }

        String userInfoFile = "user-info.json";
        if (!MainFilesHelper.fileExist(userInfoFile, this)) {
            JSONObject userInfoObj = new JSONObject();
            MainFilesHelper.writeToFile(userInfoFile, userInfoObj.toString(), this);

            // TODO: remove it
            try {
                ChatsStorage.addDummyItems(this);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        JSONObject userInfoObj = null;
        try {
            userInfoObj = new JSONObject(MainFilesHelper.readFile(userInfoFile, this));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String intStr = "android.intent.action.RegsterForm";

        if (userInfoObj.has("id")) {
            intStr = "android.intent.action.ChatsListing";
        }

        Intent intent = new Intent(intStr);
        startActivity(intent);

        BackgroundTask b = new BackgroundTask();
        b.execute();
    }

    class BackgroundTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                SocketHelper.socket = new java.net.Socket(InetAddress.getByName(getString(R.string.server_host)), Integer.parseInt(getString(R.string.server_port)));

                Log.d("xxx", "Connected to server ...");
                DataInputStream in = new DataInputStream(SocketHelper.socket.getInputStream());
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                //String data = "POST /WHATAREWEDOING HTTP/1.1\r\nHost: 418a-95-42-121-24.ngrok.io\r\nUser-Agent: VladoFox\r\nAccept: */*\r\n\r\ndasndjsdhjsdj super sexy data";
                String data = "POST /WHATAREWEDOING HTTP/1.1\r\nHost: 418a-95-42-121-24.ngrok.io\r\nUser-Agent: VladoFox\r\nAccept: */*\r\n\r\nd";
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();


                Log.d("xxx", "sent something now read ...");

                Log.d("xxx", "Sent data to server");
                Log.d("xxx", "Data read from server");


                // 5 seconds after starting the app
                // send some request again to the server
                // to check if the infinite loop below works.
                /*
                new android.os.Handler(Looper.getMainLooper()).postDelayed(
                        new Runnable() {
                            public void run() {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            out.write(dataInBytes);
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                            }
                        },
                        5 * 1000);
                 */

                while(true) {
                    String line = in.readLine();

                    if(line != null) {
                        Log.d("xxx____", line);
                    }
                }


                /*
                // Hopefully we won't need this monst ever again.
                // Keep it just in case.

                int length = 5;;
                Log.d("xxx", "length: " + length);

                byte[] msgBuffer = new byte[length]; // Буфер за съобщението
                int bytesRead = 0; // Брой прочетени байта
                boolean hasBuffer = true; // Очакващ патент "Има-ли-още-данни" флаг

                // Правим стринг, не по-голям от очакваната дължина
                StringBuffer dataString = new StringBuffer(length);

                while (hasBuffer) {
                    // цикъл, в който четем
                    int byteToRead;
                    try {
                        byteToRead = in.read(msgBuffer); // Четем в буфера
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                    bytesRead = byteToRead + bytesRead;

                    if (bytesRead <= length) {
                        dataString.append(new String(msgBuffer, 0, byteToRead, StandardCharsets.UTF_8));
                    } else {
                        dataString.append(new String(msgBuffer, 0, length - bytesRead + byteToRead, StandardCharsets.UTF_8));
                    }

                    // Remove it?
                    // Ако прочетеното е >= дължината, край
                    if (dataString.length() >= length) {
                        hasBuffer = false;
                    }
                }

                Log.d("xx_______", dataString.toString());
                 */
            }
            catch (Exception ex) {
                ex.printStackTrace();
                Log.d("xxx", "greshka");
            }


            return "";
        }
    }
}