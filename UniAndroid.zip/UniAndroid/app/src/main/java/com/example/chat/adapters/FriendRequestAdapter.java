package com.example.chat.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.InvitationsListing;
import com.example.chat.R;
import com.example.chat.SocketHelper;
import com.example.chat.models.FriendRequest;
import com.example.chat.models.Invitation;
import com.example.chat.models.Message;
import com.example.chat.storage.MainFilesHelper;

import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class FriendRequestAdapter extends RecyclerView.Adapter<FriendRequestAdapter.ViewHolder> {

    public ArrayList<FriendRequest> friendRequests;
    private Context context;

    public static FriendRequestAdapter adapterContext;

    public static int invitationID;

    public FriendRequestAdapter(ArrayList<FriendRequest> friendRequests, Context context) {
        this.friendRequests = friendRequests;
        this.context = context;

        FriendRequestAdapter.adapterContext = this;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_received_friend_request, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FriendRequest fr = friendRequests.get(position);
        holder.friendRequestUsername.setText(fr.getSenderName());

        FriendRequestAdapter that = this;

        holder.denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                invitationID = friendRequests.get(position).getId();
                friendRequests.remove(position);

                that.notifyDataSetChanged();

                DenyInvitation commThread = new DenyInvitation();
                new Thread(commThread).start();
            }
        });

        holder.acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                invitationID = friendRequests.get(position).getId();
                friendRequests.remove(position);

                that.notifyDataSetChanged();

                AcceptInvitation commThread = new AcceptInvitation();
                new Thread(commThread).start();
            }
        });
    }

    @Override
    public int getItemCount() {
        return friendRequests.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView friendRequestUsername;
        public Button denyButton;
        public Button acceptButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            friendRequestUsername = (TextView) itemView.findViewById(R.id.friendRequestUsername);
            denyButton = (Button) itemView.findViewById(R.id.button_deny_invitations);
            acceptButton = (Button) itemView.findViewById(R.id.button_accept_invitation);
        }
    }

    class AcceptInvitation implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject invData = new JSONObject();
                invData.put("requestType", SocketHelper.MODIFY_INVITATION);
                invData.put("user", MainFilesHelper.getUserID(InvitationsListing.context));
                invData.put("invitationID", FriendRequestAdapter.invitationID);
                invData.put("status", Invitation.STATUS_ACCEPTED);

                String data = invData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    class DenyInvitation implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject invData = new JSONObject();
                invData.put("requestType", SocketHelper.MODIFY_INVITATION);
                invData.put("user", MainFilesHelper.getUserID(InvitationsListing.context));
                invData.put("invitationID", FriendRequestAdapter.invitationID);
                invData.put("status", Invitation.STATUS_DENIED);

                String data = invData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
