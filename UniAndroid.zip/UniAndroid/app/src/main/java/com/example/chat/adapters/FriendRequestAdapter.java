package com.example.chat.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat.R;
import com.example.chat.models.FriendRequest;

import java.util.ArrayList;

public class FriendRequestAdapter extends RecyclerView.Adapter<FriendRequestAdapter.ViewHolder> {

    ArrayList<FriendRequest> friendRequests;
    private Context context;

    public FriendRequestAdapter(ArrayList<FriendRequest> friendRequests, Context context) {
        this.friendRequests = friendRequests;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_received_friend_request, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FriendRequest fr = friendRequests.get(position);
        holder.friendRequestUsername.setText(fr.getSenderName());

        holder.denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("xyz", "deny");
            }
        });

        holder.acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("xyz", "accept");
            }
        });
    }

    @Override
    public int getItemCount() {
        return friendRequests.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView friendRequestUsername;
        public Button denyButton;
        public Button acceptButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            friendRequestUsername = (TextView) itemView.findViewById(R.id.friendRequestUsername);
            denyButton = (Button) itemView.findViewById(R.id.button_deny_invitations);
            acceptButton = (Button) itemView.findViewById(R.id.button_accept_invitation);
        }
    }
}
