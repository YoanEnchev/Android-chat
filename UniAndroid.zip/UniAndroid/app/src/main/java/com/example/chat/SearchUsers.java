package com.example.chat;

import android.content.Intent;
import android.os.Bundle;

import com.example.chat.adapters.ChatItemsAdapter;
import com.example.chat.adapters.UserItemAdapter;
import com.example.chat.models.User;
import com.example.chat.storage.MainFilesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class SearchUsers extends AppCompatActivity {

    public static SearchUsers context;
    public static String searchPhrase;

    public static UserItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_users);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView usersList = (RecyclerView) findViewById(R.id.usersList);
        usersList.setLayoutManager(new LinearLayoutManager(this));

        // Initially no users are shown.
        ArrayList<User> users = new ArrayList<>();
        UserItemAdapter adapter = new UserItemAdapter(users, this);
        usersList.setAdapter(adapter);

        SearchUsers.adapter = adapter;

        Button searchBtn = findViewById(R.id.button_search_users);
        EditText editTextPhrase = findViewById(R.id.search_username);

        Button createGroupBtn = findViewById(R.id.button_create_group);

        context = this;

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                SearchUsers.searchPhrase = editTextPhrase.getText().toString();

                SearchUsersForFriendships commThread = new SearchUsersForFriendships();
                new Thread(commThread).start();
            }
        });

        createGroupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CreateChat commThread = new CreateChat();
                new Thread(commThread).start();
            }
        });
    }

    public void updateUsersList(JSONArray usersArr) {

        ArrayList<User> users = new ArrayList<>();

        try {
            for (int i = 0; i < usersArr.length(); i++) {
                JSONObject obj = (JSONObject) usersArr.get(i);
                User user = new User(obj.getString("name") ,obj.getInt("id"));

                users.add(user);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SearchUsers.adapter.users = users;
        SearchUsers.adapter.notifyDataSetChanged();
    }

    class SearchUsersForFriendships implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.SEARCH_USERS_FOR_INVITATION);
                regData.put("phrase", SearchUsers.searchPhrase);
                regData.put("userID", MainFilesHelper.getUserID(context));

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    class CreateChat implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject chatData = new JSONObject();
                chatData.put("requestType", SocketHelper.CREATE_GROUP);
                chatData.put("userID", MainFilesHelper.getUserID(context));

                String data = chatData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}