package com.example.chat;

import android.os.Bundle;

import com.example.chat.adapters.ChatItemsAdapter;
import com.example.chat.adapters.UserItemAdapter;
import com.example.chat.models.User;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class SearchUsers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_users);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView usersList = (RecyclerView) findViewById(R.id.usersList);
        usersList.setLayoutManager(new LinearLayoutManager(this));

        // Initially no users are shown.
        ArrayList<User> users = new ArrayList<>();
        UserItemAdapter adapter = new UserItemAdapter(users, this);
        usersList.setAdapter(adapter);

        Button searchBtn = findViewById(R.id.button_search_users);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                ArrayList<User> users = new ArrayList<User>();
                String names[] = {"Alice", "Bob", "Carl", "Dilan", "GJ", "Hokaido", "Imp", "Joe", "Kol", "Lizellot", "Max"};
                for(int i = 1; i<= 10; i++) {
                    User user = new User(names[i], i);
                    users.add(user);
                }

                // TODO: filter them in server and send request.
                adapter.users = users;
                adapter.notifyDataSetChanged();
            }
        });
    }
}