package com.example.chat;

import android.app.Activity;
import android.os.CountDownTimer;
import android.util.Log;

public class SocketRefreshHelper {
    public static CountDownTimer createSocketRefresher(Activity context, String name) {

        CountDownTimer cdt = new CountDownTimer(999999 * 1000, (long) (Double.parseDouble(context.getString(R.string.refresh_secs)) * 1000)) {
            @Override
            public void onTick(long millisUntilFinished) {
                Log.i("xx", "extract " + name);

                switch (name) {
                    case "messages":
                        OpenedChat.ExtractChatMessages m = new OpenedChat.ExtractChatMessages();
                        new Thread(m).start();
                        break;
                    case "invitations":
                        InvitationsListing.ExtractInvitations i = new InvitationsListing.ExtractInvitations();
                        new Thread(i).start();
                        break;
                    case "chats":
                        ChatsListing.ExtractChats c = new ChatsListing.ExtractChats();
                        new Thread(c).start();
                        break;
                }
            }

            @Override
            public void onFinish() {

            }
        };

        cdt.start();

        return cdt;
    }
}
