package com.example.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.chat.sharedViewModels.LoginRegisterForms;
import com.example.chat.storage.MainFilesHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;

public class Register extends AppCompatActivity implements View.OnClickListener {

    Button bRegister;
    EditText etUsername, etPassword;
    TextView goToLogin, usernameMessage, passwordMessage;

    private static String filledUsername;
    private static String filledPassword;
    static Register context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        bRegister = (Button) findViewById(R.id.bRegister);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        goToLogin = (TextView) findViewById(R.id.loginLink);
        usernameMessage = (TextView) findViewById(R.id.usernameMessage);
        passwordMessage = (TextView) findViewById(R.id.passwordMessage);

        bRegister.setOnClickListener(this);
        goToLogin.setOnClickListener(this);

        Register.context = this; // ненормална работа просто...
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bRegister:

                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                filledUsername = username.trim();
                filledPassword = password.trim();

                String usernameErrorMsg = LoginRegisterForms.isUsernameValid(username);
                String passwordErrorMsg = LoginRegisterForms.isPasswordValid(password);

                usernameMessage.setText(usernameErrorMsg);
                passwordMessage.setText(passwordErrorMsg);

                if(usernameErrorMsg.length() == 0 && passwordErrorMsg.length() == 0) {
                    // TODO: send a request to server and analyze it's response

                    try {
                        JSONObject userInfoObj = new JSONObject();
                        userInfoObj.put("username", username);
                        userInfoObj.put("id", 1); // TODO: replace with response result.
                        MainFilesHelper.writeToFile("user-info.json", userInfoObj.toString(), this);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Register.RegisterAttempt commThread = new Register.RegisterAttempt();
                    new Thread(commThread).start();
                }

                break;
            case R.id.loginLink:
                Intent intent = new Intent("android.intent.action.LoginForm");
                startActivity(intent);
                break;
        }
    }

    public void handleSuccessfulRegister(int userID) {

        runOnUiThread(() -> {
            try {
                JSONObject userInfoObj = new JSONObject();
                userInfoObj.put("username", Register.filledUsername);
                userInfoObj.put("id", userID);
                MainFilesHelper.writeToFile("user-info.json", userInfoObj.toString(), Register.context);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }

            Intent intent = new Intent("android.intent.action.ChatsListing");
            startActivity(intent);
        });
    }

    class RegisterAttempt implements Runnable {

        @Override
        public void run() {
            try {
                DataOutputStream out = new DataOutputStream(SocketHelper.socket.getOutputStream());

                JSONObject regData = new JSONObject();
                regData.put("requestType", SocketHelper.REGISTER);
                regData.put("name", Register.filledUsername);
                regData.put("password", Register.filledPassword);

                String data = regData.toString();
                byte[] dataInBytes = data.getBytes(StandardCharsets.UTF_8);

                out.write(dataInBytes);
                out.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}