package com.example.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.chat.sharedViewModels.LoginRegisterForms;

public class Register extends AppCompatActivity implements View.OnClickListener {

    Button bRegister;
    EditText etUsername, etPassword;
    TextView goToLogin, usernameMessage, passwordMessage;;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        bRegister = (Button) findViewById(R.id.bRegister);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        goToLogin = (TextView) findViewById(R.id.loginLink);
        usernameMessage = (TextView) findViewById(R.id.usernameMessage);
        passwordMessage = (TextView) findViewById(R.id.passwordMessage);

        bRegister.setOnClickListener(this);
        goToLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bRegister:

                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                String usernameErrorMsg = LoginRegisterForms.isUsernameValid(username);
                String passwordErrorMsg = LoginRegisterForms.isPasswordValid(password);

                usernameMessage.setText(usernameErrorMsg);
                passwordMessage.setText(passwordErrorMsg);

                if(usernameErrorMsg.length() == 0 && passwordErrorMsg.length() == 0) {

                    // TODO: send a request to server and analyze it's response

                    Intent intent = new Intent("android.intent.action.ChatsListing");
                    startActivity(intent);
                }

                break;
            case R.id.loginLink:
                Intent intent = new Intent("android.intent.action.LoginForm");
                startActivity(intent);
                break;
        }
    }
}