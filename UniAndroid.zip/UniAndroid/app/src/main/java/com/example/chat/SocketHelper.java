package com.example.chat;

import java.net.Socket;

public class SocketHelper {
    public static Socket socket;
}
