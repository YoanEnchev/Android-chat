package com.example.chat;

import java.net.Socket;

public class SocketHelper {
    public static Socket socket;

    public static final int LOGIN = 1;
    public static final int REGISTER = 2;

    public static final int EXTRACT_CHATS = 3;

    public static final int EXTRACT_INVITATIONS = 4;
    public static final int MODIFY_INVITATION = 5;
    public static final int SEND_INVITATION = 6;

    // TODO: recheck it
    public static final int EXTRACT_CHAT_MESSAGES = 7;


    public static final int SEND_MESSAGE = 8;
    public static final int EDIT_MESSAGE = 9;

    public static final int SEARCH_USERS_FOR_INVITATION = 10;
    public static final int SEARCH_USERS_FOR_GROUP = 11;

    public static final int CREATE_GROUP = 12;
    public static final int ADD_USER_TO_GROUP = 13;
}
