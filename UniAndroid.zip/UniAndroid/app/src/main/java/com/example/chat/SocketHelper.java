package com.example.chat;

import java.net.Socket;

public class SocketHelper {
    public static Socket socket;

    public static final int LOGIN_ATTEMPT_REQUEST = 1;
    public static final int REGISTER_ATTEMPT_REQUEST = 2;



    public static final int LOGIN_RESPONSE = 0;
}
